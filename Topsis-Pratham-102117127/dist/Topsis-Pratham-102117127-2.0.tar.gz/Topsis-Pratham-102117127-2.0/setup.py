from setuptools import setup
setup(name = 'Topsis-Pratham-102117127',
      version = "2.0",
      description = "Topsis Score Calculator with accepts input on CLI" ,
      author ="Pratham Aggarwal",
      packages =['Topsis-Pratham-102117127'],
      install_requires = ['pandas'] )